# ARB//BOT — Polymarket ↔ Kalshi Cross-Exchange Scanner

Finds price discrepancies for the same event between Polymarket and Kalshi,
calculates Kelly-optimal bet sizing, and displays everything on a live dashboard.

---

## How to deploy (step by step)

### Step 1 — Make a GitHub account
Go to https://github.com and sign up.

### Step 2 — Create a new repository
- Click the green "New" button
- Name it `arb-bot`
- Set it to Public
- Click "Create repository"

### Step 3 — Upload the files
- Click "uploading an existing file"
- Drag ALL the files from this folder into the upload area:
  - server.js
  - matcher.js
  - kelly.js
  - package.json
  - public/index.html  ← make sure to create the public folder first
- Click "Commit changes"

### Step 4 — Deploy on Railway
- Go to https://railway.app
- Click "Start a New Project"
- Choose "Deploy from GitHub repo"
- Connect your GitHub account and select `arb-bot`
- Railway will detect it's a Node.js app automatically
- Click Deploy

### Step 5 — Get your public URL
- In Railway, go to your project → Settings → Domains
- Click "Generate Domain"
- You'll get a URL like `arb-bot-production.up.railway.app`
- That's your live dashboard — share it with your teacher!

---

## How it works

1. Every 60 seconds the bot fetches live markets from both exchanges
2. It runs a fuzzy matching algorithm to find the same event on both platforms
3. For each match, it checks if there's a price discrepancy after fees
4. If YES price on Polymarket + NO price on Kalshi < $1.00, that's free money
5. It calculates Kelly criterion bet sizing for bankroll management
6. Everything updates live on the dashboard via WebSocket

## The arb logic

If Polymarket says YES = 62¢ and Kalshi says YES = 68¢:
- Buy YES on Polymarket for 62¢
- Buy NO on Kalshi for 32¢ (since NO = 1 - 68¢)
- Total cost = 94¢
- Guaranteed payout = $1.00
- Locked profit = 6¢ per unit (minus fees)

## Config (edit in server.js or via the dashboard UI)

| Setting | Default | Description |
|---|---|---|
| POLL_INTERVAL_MS | 60000 | How often to scan (ms) |
| MIN_NET_SPREAD | 0.03 | Minimum 3% spread after fees |
| POLY_FEE | 0.02 | Polymarket taker fee |
| KALSHI_FEE | 0.02 | Kalshi taker fee |
| KELLY_FRACTION | 0.25 | Quarter-Kelly (conservative) |
| BANKROLL | 1000 | Your capital in USD |

## Stack
- Node.js + Express (web server)
- WebSockets (live dashboard updates)
- Vanilla HTML/CSS/JS (no frameworks needed)
- Polymarket Gamma API (public, no auth)
- Kalshi Trade API (public markets endpoint)
